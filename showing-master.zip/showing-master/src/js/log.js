var log = function (msg) {
    console.log('--------------------');
    console.log(msg);
    console.log('--------------------');
}

log({a:1});
log('gulp-book');